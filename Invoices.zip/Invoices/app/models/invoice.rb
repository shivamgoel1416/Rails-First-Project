class Invoice < ApplicationRecord
end
